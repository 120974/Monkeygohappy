var monkey, monkey_running, monkey_collided;
var ground, invisibleGround, groundImage;
var bananaGroup
var stoneGroup
var bananaImage
var stone1
var score
function preload(){
monkey_running=loadAnimation("Monkey_01.png", "Monkey_02.png", "Monkey_03.png", "Monkey_04.png", "Monkey_05.png", "Monkey_06.png", "Monkey_07.png", "Monkey_08.png", "Monkey_09.png", "Monkey_10.png")
  bananaImage = loadImage("Banana.png");
  groundImage = loadImage("jungle2.jpg")
  stone1 = loadImage("stone.png");
}

function setup() {
  createCanvas(400,200);

  
  ground = createSprite(400,100,400,200);
  ground.addImage("ground",groundImage);
  ground.x = ground.width /5;
  ground.velocityX = -4;
  ground.scale=0.5;

  score = createSprite(20,360,50,100 ) 
  
  invisibleGround = createSprite(200,190,400,10);
  invisibleGround.visible = false;
  
  monkey = createSprite(50,180,20,50);
  monkey.addAnimation("running", monkey_running);
  monkey.scale = 0.1;
  switch(score){
    case 10: monkey.scale=0.12;
          break;
    case 20: monkey.scale=0.14
          break;
    case 30: monkey.scale=0.16
          break;
    case 40: monkey.scale=0.18
          break;
    default: break;
  }
 if(stoneGroup.isTouching (monkey)) {
    monkey.scale=0.2;
  }

  bananaGroup=new Group();
  
  stoneGroup=new Group();
}

function draw() {
  background(180);
  
  if(keyDown("space")&&monkey.y>=40){
    monkey.velocityY=-10; 
    
  }
  
  monkey.velocityY = monkey.velocityY + 0.8
  
  if (ground.x < 150){
    ground.x = ground.width/4;
  }
  
  monkey.collide(invisibleGround);
  spawnObstacles();
  spawnBanana();
  drawSprites();
}
function spawnObstacles() {
  if(World.frameCount % 60 === 0) {
    var obstacle = createSprite(600,160,10,40);
    obstacle.velocityX = -6;    
    obstacle.addImage(stone1);
    //assign scale and lifetime to the obstacle           
    obstacle.scale = 0.1;
    obstacle.lifetime = 200;
  }
}  

function spawnBanana() {
  //write code here to spawn the clouds
  if (World.frameCount % 60 === 0) {
    var banana = createSprite(600,50,40,10);
    banana.y = random(50,120);
    banana.addImage(bananaImage);
    banana.scale = 0.05;
    banana.velocityX = -3;
    
     //assign lifetime to the variable
    banana.lifetime = 200;
    
    //adjust the depth
    banana.depth = monkey.depth;
    monkey.depth = monkey.depth + 1;
  }
} 